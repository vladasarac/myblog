@extends('layouts.dashboard')


@section('content')
  <div class="col-sm-9 main">

    <h2 class="sub-header">Dashboard</h2>
    <div class="table-responsive">
      <p>Welcome Admin, you can add, update, delete any post, comment, draft etc...</p>
      <p><a href="https://xhamster.com/">XHamster</a></p>        
    </div>
  </div>
@endsection




