@extends('layouts.app')

@section('content')
  
  <p>{{ $author }}</p>

@endsection