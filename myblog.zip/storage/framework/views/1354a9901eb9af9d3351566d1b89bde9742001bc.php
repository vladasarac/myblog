<?php $__env->startSection('content'); ?>
  <div class="col-sm-9 main">

    <h2 class="sub-header">Dashboard</h2>
    <div class="table-responsive">
      <p>Welcome Admin, you can add, update, delete any post, comment, draft etc...</p>
      <p><a href="https://xhamster.com/">XHamster</a></p>        
    </div>
  </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>