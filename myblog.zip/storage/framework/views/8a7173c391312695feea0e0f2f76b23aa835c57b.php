<?php /*vju za kreiranje novog posta (koristimo tinymce plugin da bi textarea za kreiranje posta izgledala kao text editor)*/ ?>
<?php $__env->startSection('content'); ?>
  <h2>Create New Post</h2>
  <?php /*dodavanje tinymce plugina*/ ?>
  <script type="text/javascript" src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  <script type="text/javascript">
    tinymce.init({
      selector : "textarea",
      plugins : ["advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste"],
      toolbar : "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
      // ja dodao ovako mozemo slici koju dodajemo dodati klasu img-responsive da bi se prilagodjavala velicini ekrana
      image_class_list: [
        {title: 'None', value: ''},
        {title: 'responsive', value: 'img-responsive'},
      ],
      
    });
  </script>
  <?php /* forma za kreiranje posta, posto se mogu dodatui i slike mora biti enctype="multipart/form-data" */ ?>
  <form action="<?php echo e(url('/admin/posts/createpost')); ?>" method="post" enctype="multipart/form-data">
  	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  	<div class="form-group">
  	  <p>Title</p><?php /*nslov posta*/ ?>
  	  <input type="text" name="title" value="<?php echo e(old('title')); ?>" required="required" placeholder="Enter title here" class="form-control">
  	  <br>
  	  <p>Description</p><?php /*description posta*/ ?>
  	  <input type="text" name="description" value="<?php echo e(old('description')); ?>" required="required" placeholder="Enter description here" class="form-control">	
  	  <br>
  	  <p>Thumbnail</p>
  	  <img src="http://placehold.it/100x100" id="showimages" style="max-width:200px;max-height:200px;float:left;">
  	  <div class="row">
  	  	<div class="col-md-12">
  	  	  <input type="file" id="inputimages" name="images">	
  	  	</div>
  	  </div>
  	</div>
  	<?php /*textarea za unos body-a posta*/ ?>
  	<div class="form-group">
  	  <textarea name="body" class="form-control" rows="20"></textarea>	
  	</div>
  	<?php /*ako zelimo da objavimo post tj da active kolona 'posts' tabele bude 1 onda ovaj btn*/ ?>
  	<input type="submit" name="publish" class="btn btn-success" value="Publish">
  	<?php /*ako zelimo samo da sacuvamo posta a kolona active 'posts' tabele ce biti 0 tj nece biti vidljiv obicnim posetiocima onda ovaj btn*/ ?>
  	<input type="submit" name="save" class="btn btn-success" value="Save Draft">
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>