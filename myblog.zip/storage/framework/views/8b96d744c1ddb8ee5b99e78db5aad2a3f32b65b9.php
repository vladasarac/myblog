<?php /*vju koji prikazuje jedan post i dodate komentare*/ ?>

<?php $__env->startSection('header'); ?>
  <div class="post-heading">
    <h1><?php echo e($post->title); ?></h1> <?php /*naslov posta*/ ?>
    <h2 class="subheading"><?php echo e($post->description); ?></h2> <?php /*podnaslov tj description*/ ?>  
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php if($post): ?>  <?php /* ako ima trazenog posta */ ?>
    <div class="">
      <?php /*datum kreiranja posta i podatci autora koji su link ka ruti 'author' koja gadja author() metod frontend PostsControllera koji prikazuje sve tekstove jednog autora*/ ?>
      <span class="meta">
        <?php echo e($post->created_at->format('M d,Y \a\t h:i a')); ?> By 
        <a href="<?php echo e(url('/author/'.$post->author_id)); ?>">
          <b><?php echo e($post->author->name); ?></b>
          <img src="<?php echo e(asset('img/authors/' . $post->author->image)); ?>" class="img-circle" id="showimages" height="50" width="50"><br><br>
        </a>  
      </span>
      <?php echo $post->body; ?>	
    </div>
    <?php /*ako user nije ulogovan ne moze komentarisati post, mora biti ulogovan (barem kao subscriber)*/ ?>
    <?php if(Auth::guest()): ?>
 	  <p>
 	  	Please Login to Comment
 	  </p>
    <?php else: ?>
      <?php /*ako je ulogovan moze komentarisati*/ ?>
      <div class="">
        <h3>Leave a Comment</h3>	
      </div>
      <div class="panel-body">
        <?php /*forma za dodavanje komentara*/ ?>
      	<form class="" action="/comment/add" method="post">
      	  <?php /*skrivena polja u kojima su _token, id posta i slug posta(???)*/ ?>
      	  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">  
      	  <input type="hidden" name="on_post" value="<?php echo e($post->id); ?>">  
      	  <input type="hidden" name="slug" value="<?php echo e($post->slug); ?>">  	
      	  <div class="form-group">
      	    <?php /*text aerea u koju se upisuje komentar*/ ?>
      	  	<textarea required="required" placeholder="Enter comment here" name="body" class="form-control"></textarea>
      	  </div>
      	  <input type="submit" name="post_comment" class="btn btn-success" value="Post">
      	</form>
      </div>
    <?php endif; ?>
    <div class=""><?php /*ako ima komentara prikazi ih*/ ?>
      <?php if($comments): ?>
        <ul style="list-style: none; padding: 0">
          <?php foreach($comments as $comment): ?>
            <li class="panel-body">
              <div class="list-group">
              	<div class="list-group-item">
              	  <h3><?php echo e($comment->author->name); ?></h3>
              	  <p><?php echo e($comment->created_at->format('M d,Y \a\t h:i a')); ?></p>	
              	</div>
              	<div class="list-group-item">
              	  <p><?php echo e($comment->body); ?></p>	
                  
                  <?php /*btn tj ikone za Like ili Dislike komentara, prvo prikazuje koliko komentar vec ima lajkova i dislajkova a onda proverava
                  da li postoji cookie likeordislikeIDKOMENTARA i ako ima to znaci da je vec sa kompjutera lajkovan ili dislajkovan komentar -
                  -(to pise u kukiju 'like' ili 'dislike') a ako nije prikazuje ikone za like i dislike ciji su hendleri u likedislike.js*/ ?>
                  <div id="like_dislike">
                    <?php /* <p hidden="true" id="<?php echo e($comment->id); ?>"></p> */ ?>
                    <?php /*prikaz broja lajkova i dislajkova komentara(kolone like i dislike 'comments' tabele),spanovi sa  id likes+IDKOMENTARA i 
                    id dislikes+IDKOMENTARA sluze da bi u likedislike.js mogli da promenimo broj trenutnih lajkova i dislajkova komentara kad
                    korisnik klikne neku ikonu*/ ?>
                    <span class="text-success">Likes (<span id="likes<?php echo e($comment->id); ?>"><?php echo e($comment->like); ?></span>)</span>
                    <span class="text-danger pull-right">Dislikes (<span id="dislikes<?php echo e($comment->id); ?>"><?php echo e($comment->dislike); ?></span>)</span><br>
                    <?php /*kad korisnik lajkuje ili dislajkuje komentar i kad kontroler vrati odgovor manjamo sadrzaj ovog diva u likedislike.js
                    obrisacemo ikone i ako je lajkovao ispisati Liked ili ako je dislajkovao Disliked*/ ?>
                    <div id="likeordislike<?php echo e($comment->id); ?>">
                      <?php /*ako postooji cookie likeordislikeIDKOMENTARA i njegova vrednost je like*/ ?>
                      <?php if(Cookie::get('likeordislike'.$comment->id) == 'like'): ?> 
                        <p class="likeilidislike text-success text-center">Liked</p><?php /*prikazi tekst Liked*/ ?>
                      <?php /*ako postooji cookie likeordislikeIDKOMENTARA i njegova vrednost je dislike*/ ?>
                      <?php elseif(Cookie::get('likeordislike'.$comment->id) == 'dislike'): ?>
                        <p class="likeilidislike text-danger text-center">Disliked</p><?php /*prikazi tekst Disliked*/ ?>
                      <?php else: ?><?php /*ako ne postooji cookie likeordislikeIDKOMENTARA prikazujemo ikone za Like i Dislike ispod komentara*/ ?>
                        <span commentid="<?php echo e($comment->id); ?>" likeordislike="like" class="likedislikebtn"><img alt="brand" src="<?php echo e(asset('img/like.png')); ?>" width="50" height="50"></span>
                        <span commentid="<?php echo e($comment->id); ?>" likeordislike="dislike" class="likedislikebtn pull-right"><img alt="brand" src="<?php echo e(asset('img/dislike_red.png')); ?>"  width="50" height="50"></span>
                      <?php endif; ?> 
                    </div>
                  </div>

              	</div>
              </div>	
            </li>
          <?php endforeach; ?>	
        </ul>
      <?php endif; ?>	
    </div>
  <?php else: ?> <?php /*ako nije pronadjen post ???*/ ?>

  <?php endif; ?>
  <?php /* u app.blade.php layoutu je dodata <style> u kom pise da je sirina <iframe> 100% a ovde mu racunamo visinu tako sto podelimo tu vis-
  inu sa 1.73 i taj broj damo kao visinu <iframe> - a */ ?>
  <script type="text/javascript">
    $(document).ready(function(){
      var ifwidth = $('iframe').width();
      $("iframe").height(ifwidth / 1.73);
    }); 

    //ovo nam treba za lajkovanje i dislajkovanje komentara tj ove varijable koristi likedislike.js kad salje AJAX u likeordislike()CommentsControllera
    var token = '<?php echo e(Session::token()); ?>';
    var likeordislikeurl = '<?php echo e(route('likeordislike')); ?>';
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>