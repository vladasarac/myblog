<?php /* vju koji poziva metod allUsers() AuthorsCOntrollera kad se u admin dashboardu klikne link users(link je vidljiv samo adminima) i sluzi
  da se pronadje neki user i onda se moze obrisati ili proglasiti za Admina ili Authora, sve to rade hendleri u searchusers.js*/ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-9">
    <h3>Find User</h3>
    <input type="text" name="searchuser" id="searchuser" class="form-control" placeholder="Find User...">
    <hr> 
  </div>
</div>

<div class="row">
  <div class="col-md-9">
  <?php /*div u koji ce se ubacivati HTML koji se generise posle slanja AJAX-a iz searchusers.js kad se unese nesto u input #searchuser*/ ?>
    <div class="searchresults">
    
    </div>
  </div>
</div>

<script type="text/javascript">

    //ove varijable se koriste pri slanju AJAX-a iz searchusers.js
    var token = '<?php echo e(Session::token()); ?>';
    var url = '<?php echo e(route('searchusers')); ?>';
    var makeadminorauthorurl = '<?php echo e(route('makeadminorauthor')); ?>';
    var deleteuserurl = '<?php echo e(route('deleteuser')); ?>';
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>