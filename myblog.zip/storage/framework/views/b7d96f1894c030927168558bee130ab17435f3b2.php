<?php /* fajl prikazuje poslednjih 5 postova koje mu salje index() metod PostsControllera a yielduje ga layout app.blade.php */ ?>

<?php $__env->startSection('header'); ?>
  <div class="site-heading">
    <h1>MyBlog</h1>
    <hr class="small">
    <span class="subheading">A Clean Blog Theme by Start Bootstrap</span>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php /*prikazi errore ako ih ima, ja dodo*/ ?>
  <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
      <ul>
        <?php foreach($errors->all() as $error): ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <?php /* Ja dodo, metod author() frontend PostsCntrollera vadi postove jednog autora i salje ih u ovaj vju i ovde prikazujemo ime tog autora */ ?>
  <?php /* medjutim posto kad se iz index metoda poziva ovaj vju ne stize $author varijabla jer ionako u tom slucaju ne treba da stampa ime autora*/ ?>
  <?php if(!empty($author)): ?> <?php /*u author se nalazi zapravo id autora ali je to samo provera da vju zna koji metod ga je pozvao*/ ?>
  <?php /*ovde stampamo ime autora prvog posta (posto ionako u ovom slucaju svi postove imaju istog autora)*/ ?>
  <?php if(count($posts) <= 0): ?>
    There is no post till now. Login and write a new post now!!!
  <?php else: ?>
    <h1 class="text-info">Postovi Autora <?php echo e($posts[0]->author->name); ?></h1><hr>
  <?php endif; ?>
    <?php /* dodajemo da prikaze bio kolonu 'users' tabele tj biografiju autora cije postove gledamo, ovo se prikazuje samo ako kolona bio u -
       -'users' tabeli nije NULL tj ako je autoru dodata biografija*/ ?>
    <?php if(!empty($posts[0]->author->bio)): ?> 
      <div id="authorbio">
        <?php echo $posts[0]->author->bio; ?>      
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <?php /*ako index() metod PostsControllera nije nista vratio ispisi da nema postova*/ ?>
  <?php /*<?php if(!$posts->count()): ?> */ ?>
  <?php if(count($posts) <= 0): ?>
    There is no post till now. Login and write a new post now!!!
  <?php else: ?>
    <?php /*ako je nesto vratio prikazi te postove*/ ?>
    <?php foreach($posts as $post): ?>
      <h2 class="post-title"><?php /*naslov posta*/ ?>
        <a href="<?php echo e(url('/'.$post->slug)); ?>"><?php echo e($post->title); ?></a>    
      </h2>
      <p class="post-subtitle"><?php /*prvih 120 karaktera body-a posta sa linkom Read More*/ ?>
        <?php echo str_limit($post->body, $limit = 120, $end = '..... <a href='.url("/".$post->slug).'>Read More</a>'); ?>    
      </p>
      <p class="post-meta"><?php /*datum kreiranja posta, sa imenom autora koji ide na rutu '/user'*/ ?>
        <?php echo e($post->created_at->format('M d,Y \a\t h:i a')); ?> By <a href="<?php echo e(url('/author/'.$post->author_id)); ?>"><?php echo e($post->author->name); ?></a>  
      </p>
    <?php endforeach; ?>   
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php /*paginacija*/ ?>
<?php $__env->startSection('pagination'); ?>
  <div class="row">
    <hr>
    <?php echo $posts->links(); ?>    
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>