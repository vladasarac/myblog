<?php /*vju koji prikazuje */ ?>

<?php $__env->startSection('content'); ?>
  
<h2><?php echo e($post->title); ?></h2><br><hr>

<?php /*  */ ?>
<div class="row">
  <div class="col-md-9 searchform">
  <h3 class="text-info">Serach This Post Comments</h3>
  <form action="<?php echo e(url('/admin/posts/searchdeletecomments')); ?>" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div class="form-group">
        <input type="text" id="searchcommentsinput" name="searchcommentsinput" required="required" placeholder="Find Comments" class="form-control">
      </div>
      <div class="form-group">
        <input type="submit" id="searchcomments" name="searchcomments" class="btn btn-success" value="Search">
      </div>
    </form>

    <?php /* ako searchDeleteComments() metod backend PostsControllera uspesno obrise komentare u Session::flash ce ubaciti uspeh poruku koju ovde ispisujemo */ ?>
    <?php if(Session::has('success')): ?> 
      <div class="alert alert-success" role="alert">
        <p>Success:<?php echo e(Session::get('success')); ?></p>
      </div>
    <?php endif; ?>

  </div>
</div>




<div class="row">
  <div class="col-md-9 commentslist">

  <?php if(count($comments) <= 0): ?>
    <h2 class="text-danger">This post does not have comments!</h2>  
  <?php else: ?>
    <?php foreach($comments as $comment): ?>
  	  <p><?php echo e($comment->body); ?></p>
  	  <a href="<?php echo e(url('admin/posts/deletecomment/'.$comment->id.'?_token='.csrf_token())); ?>" onclick="return confirm('Are you sure to delete this comment?');" class="text-danger">
  	  	  	  	  Delete Comment<span class="glyphicon glyphicon-trash"></span>	
  	  </a>
  	  <h4><i>User Name:</i> <?php echo e($comment->author->name); ?>, <i>User ID:</i> <?php echo e($comment->author->id); ?></h4>
  	  <?php if($comment->author->role == "subscriber"): ?>
  	  <?php /* ovo je link za brisanje autora komentara ako mu je rola subscriber tj nije author ili admin */ ?>
 	    <a href="<?php echo e(url('admin/posts/deletecommentauthor/'.$comment->author->id.'?_token='.csrf_token())); ?>" onclick="return confirm('Are you sure to delete this comment author?');" class="text-danger">
                  Delete Comment Author<span class="glyphicon glyphicon-trash"></span> 
      </a>	
  	  <?php endif; ?>

  	  <hr>
    <?php endforeach; ?>  
  <?php endif; ?>

  </div>
</div>

<?php /* ovo je potrebno za AJAX-e koje salje searchcomments.js kad se pretrazuju ili brisu komentari nekog teksta */ ?>
<script>
  var postid = <?php echo e($post->id); ?>

  var token = '<?php echo e(Session::token()); ?>';
  var url = '<?php echo e(route('searchdeletecomments')); ?>';     
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>