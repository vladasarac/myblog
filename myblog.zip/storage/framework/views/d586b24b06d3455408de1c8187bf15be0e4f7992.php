<?php /* vju poziva getcontactform() metod ContactControllera kad se u navigaciji klikne link 'contact' ako user zeli da napise mail MyBlog-u to
moze uraditi tako sto popuni formu u ovom vjuu, forma gadja rutu /admin/sendmessage koja gadja sendmessage() metod ContactControllera koji dalje 
salje mail na adresu koja je tamo upisana*/ ?>
<?php $__env->startSection('header'); ?>
  <div class="site-heading">
    <h1 style="color: #337ab7;">Contact Us</h1> 
    <h2 class="subheading">Send EMail to MyBlog</h2> 
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php /*prikazi errore ako ih ima, tj ako validacija koju radi sendmessage() metod ContactControllera ne prodje*/ ?>
  <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
      <ul>
        <?php foreach($errors->all() as $error): ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>
  <?php /*ako je mail uspesno poslat tj sendmessage() metod ContactControllera ubacuje u Session success poruku a ovde je prikazujemo*/ ?>
  <?php if(Session::has('success')): ?> 
    <div class="alert alert-success" role="alert">
      <strong>Success:</strong><?php echo e(Session::get('success')); ?>

    </div>
  <?php endif; ?>
  <?php /*forma ima input za naslov maila i textarea za sadrzaj koju user popunjava kad salje mail, gadja metod sendmessage() ContactControlerra
  preko rute'/admin/sendmessage'*/ ?>
  <form action="<?php echo e(url('/admin/sendmessage')); ?>" method="POST">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <h3 style="color: #337ab7;">Subject:</h3>
    <div class="form-group">
	    <input id="subject" name="subject" class="form-control" value="<?php echo e(old('subject')); ?>">
	  </div>
    <h3 style="color: #337ab7;">Message:</h3>
    <div class="form-group">
      <textarea rows="15" id="message" name="message" class="form-control"><?php echo e(old('message')); ?></textarea>
	  </div>
	  <input type="submit" value="Send Message" class="btn btn-success">
  </form>
<?php $__env->stopSection(); ?>






































<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>