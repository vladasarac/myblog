<?php $__env->startSection('header'); ?>
  <div class="post-heading">
    <h1>Contact Form</h1> <?php /*naslov posta*/ ?>
    <h2 class="subheading">Send EMail to MyBlog</h2> <?php /*podnaslov tj description*/ ?>  
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Vju Contact</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>