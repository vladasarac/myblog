<?php $__env->startSection('header'); ?>
  <div class="site-heading">
    <h1>Search</h1>
    <hr class="small">
    <span class="subheading">A Clean Blog Theme by Start Bootstrap</span>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
  <div class="col-md-9">

  	<h2>Serach MyBlog</h2>
    <form action="<?php echo e(url('/admin/posts/createpost')); ?>" method="post" enctype="multipart/form-data">

  	  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

  	  <div class="form-group">
  	    <input type="text" id="searchinput" name="searchinput" required="required" placeholder="Enter something here" class="form-control">
      </div>
      <div class="form-group">
        <input type="submit" id="search" name="search" class="btn btn-success" value="Search">
      </div>
    </form>

  </div><?php /* kraj div .col-md-9 */ ?>
  </div><?php /* kraj div .row */ ?>

  <div class="body"></div>
  <div class="paginacija"></div>

  <script>
    var token = '<?php echo e(Session::token()); ?>';
  	var url = '<?php echo e(route('search')); ?>'; 
    var homeurl = '<?php echo e(url('/')); ?>'
    	
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>