<?php $__env->startSection('content'); ?>
  
  <p><?php echo e($author); ?></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>